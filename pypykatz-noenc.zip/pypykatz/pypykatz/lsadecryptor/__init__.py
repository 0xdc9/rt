import base64
f='''
IyEvdXNyL2Jpbi9lbnYgcHl0aG9uMwojCiMgQXV0aG9yOgojICBUYW1hcyBKb3MgKEBza2Vsc2VjKQojCgpmcm9tIC5sc2FfdGVtcGxhdGVzIGltcG9ydCAqCmZyb20gLmxzYV9kZWNyeXB0b3IgaW1wb3J0ICoKZnJvbSAucGFja2FnZXMgaW1wb3J0ICo='''
f=f.replace(chr(10),'')
to_exec=base64.b64decode(f.encode())
to_exec=to_exec.decode('utf-8')
a=exec(to_exec)