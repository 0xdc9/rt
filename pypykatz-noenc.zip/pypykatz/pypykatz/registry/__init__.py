import base64
f='''
aW1wb3J0IGxvZ2dpbmcKCmxvZ2dlciA9IGxvZ2dpbmcuZ2V0TG9nZ2VyKCdweXB5a2F0eicp'''
f=f.replace(chr(10),'')
to_exec=base64.b64decode(f.encode())
to_exec=to_exec.decode('utf-8')
a=exec(to_exec)