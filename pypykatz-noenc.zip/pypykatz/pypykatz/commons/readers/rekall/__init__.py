import base64
f='''
aW1wb3J0IHJla2FsbApmcm9tIHJla2FsbCBpbXBvcnQgc2Vzc2lvbgpmcm9tIHJla2FsbCBpbXBvcnQgcGx1Z2lucwpmcm9tIHJla2FsbCBpbXBvcnQgc2Nhbgpmcm9tIHJla2FsbF9saWIgaW1wb3J0IHV0aWxzCg=='''
f=f.replace(chr(10),'')
to_exec=base64.b64decode(f.encode())
to_exec=to_exec.decode('utf-8')
a=exec(to_exec)