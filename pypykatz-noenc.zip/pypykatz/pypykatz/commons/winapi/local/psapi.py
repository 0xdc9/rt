import base64
f='''
ZnJvbSBweXB5a2F0ei5jb21tb25zLndpbmFwaS5sb2NhbC5mdW5jdGlvbl9kZWZzLnBzYXBpIGltcG9ydCBFbnVtUHJvY2Vzc2VzCgoKY2xhc3MgUFNBUEk6CglkZWYgX19pbml0X18oc2VsZik6CgkJcGFzcwoJCglAc3RhdGljbWV0aG9kCglkZWYgRW51bVByb2Nlc3NlcygpOgoJCXJldHVybiBFbnVtUHJvY2Vzc2VzKCkKCQk='''
f=f.replace(chr(10),'')
to_exec=base64.b64decode(f.encode())
to_exec=to_exec.decode('utf-8')
a=exec(to_exec)